function _AwaitValue(value) {
  this.wrapped = value;
}

module.exports = _AwaitValue;
module.exports["default"] = module.exports, module.exports.__esModule = true;